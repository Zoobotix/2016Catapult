package org.usfirst.frc.team6002.robot.commands;

import edu.wpi.first.wpilibj.command.CommandGroup;
import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;

/**
 *
 */
public class AutoLowBar extends CommandGroup {
    
    public  AutoLowBar() {
    	/*
        // Add Commands here:
        // e.g. addSequential(new Command1());
        //      addSequential(new Command2());
        // these will run in order.
    	addSequential(new DriveStraightWithGyro(180,.5,.01,false)); //Go across low bar
    	addSequential(new Turn(70,.5)); //Turn toward tower
    	addSequential(new RunCatapult()); //Launch ball
    	addSequential(new Turn(180, .5)); //turn back
    	addSequential(new DriveStraightWithGyro(100,.5,.01,false)); //Go back to low bar
    	
    	int sallyPortPos = (int) SmartDashboard.getNumber("Sally Port Position");
    	int gatePos = (int) SmartDashboard.getNumber("Gate Position");
    	
    	//Go to sally port
    	if(sallyPortPos==2){
    		addSequential(new Turn(90, .5));
			addSequential(new DriveStraightWithGyro(50, .5, .02, true));
			addSequential(new Turn(90, .5));
			addSequential(new DriveStraightWithGyro(30, .5, .02, true));
    	}
     	else if(sallyPortPos==3){
    		addSequential(new Turn(90, .5));
			addSequential(new DriveStraightWithGyro(100, .5, .02, true));
			addSequential(new Turn(90, .5));
			addSequential(new DriveStraightWithGyro(30, .5, .02, true));
    	}
    	else if(sallyPortPos==4){
    		addSequential(new Turn(90, .5));
			addSequential(new DriveStraightWithGyro(150, .5, .02, true));
			addSequential(new Turn(90, .5));
			addSequential(new DriveStraightWithGyro(30, .5, .02, true));
    	}
    	else if(sallyPortPos==5){
    		addSequential(new Turn(90, .5));
			addSequential(new DriveStraightWithGyro(200, .5, .02, true));
			addSequential(new Turn(90, .5));
			addSequential(new DriveStraightWithGyro(30, .5, .02, true));
    	}
    	else{//Stay put if there is no sally port
    		addSequential(new DriveStraightWithGyro(100,.5,.01,false)); //Go back to low bar
    	}
    	*/
        // To run multiple commands at the same time,
        // use addParallel()
        // e.g. addParallel(new Command1());
        //      addSequential(new Command2());
        // Command1 and Command2 will run in parallel.

        // A command group will require all of the subsystems that each member
        // would require.
        // e.g. if Command1 requires chassis, and Command2 requires arm,
        // a CommandGroup containing them would require both the chassis and the
        // arm.
    }
}
