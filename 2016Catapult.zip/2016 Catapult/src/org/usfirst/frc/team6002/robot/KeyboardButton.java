package org.usfirst.frc.team6002.robot;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import edu.wpi.first.wpilibj.buttons.Button;
public class KeyboardButton extends Button implements KeyListener{
	private final int button; 
	private boolean isPressed = false;
	public KeyboardButton(int key){
		button = key; 
	}

	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void keyPressed(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub
		if(e.getKeyCode() == KeyEvent.VK_0 && button == 0){
			isPressed = true;
		}
		else if(e.getKeyCode() == KeyEvent.VK_1 && button == 1){
			isPressed = true;
		}
		else if(e.getKeyCode() == KeyEvent.VK_2 &&  button == 2){
			isPressed = true; 
		}
		else if(e.getKeyCode() == KeyEvent.VK_3 && button == 3){
			isPressed = true;
		}
		else if(e.getKeyCode() == KeyEvent.VK_4 && button == 4){
			isPressed = true;
		}
		else if(e.getKeyCode() == KeyEvent.VK_5 && button == 5){
			isPressed = true;
		}
		else if(e.getKeyCode() == KeyEvent.VK_6 && button == 6){
			isPressed = true;
		}
		else if(e.getKeyCode() == KeyEvent.VK_7 && button == 7){
			isPressed = true;
		}
		else if(e.getKeyCode() == KeyEvent.VK_8 && button == 8){
			isPressed = true;
		}
		else if(e.getKeyCode() == KeyEvent.VK_9 && button == 9){
			isPressed = true;
		}
		else{
			isPressed = false;
		}
	}

	@Override
	public boolean get() {
		// TODO Auto-generated method stub
		return isPressed;
	}
	
	
}
