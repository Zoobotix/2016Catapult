package org.usfirst.frc.team6002.robot;

import edu.wpi.first.wpilibj.Joystick;
import edu.wpi.first.wpilibj.buttons.Button;
import edu.wpi.first.wpilibj.buttons.JoystickButton;

public class XboxController {
	private	Joystick nojoy;
	
	public XboxController(int port){
		nojoy = new Joystick(port);
	}
	
	public double getLeftXAxis(){
		return nojoy.getRawAxis(0);
	}
	public double getLeftYAxis(){
		return nojoy.getRawAxis(1);
	}
	public double getRightXAxis(){
		return nojoy.getRawAxis(4);
	}
	public double getRightYAxis(){
		return nojoy.getRawAxis(5);
	}
	public Button getButton(int button){
		JoystickButton clicky = new JoystickButton(nojoy, button);
		return  clicky; 
	}
	public JoystickAnalogButton getTrigr(int button){
		JoystickAnalogButton snappy = new JoystickAnalogButton(nojoy, button, .5);
		return snappy;
	}
}
