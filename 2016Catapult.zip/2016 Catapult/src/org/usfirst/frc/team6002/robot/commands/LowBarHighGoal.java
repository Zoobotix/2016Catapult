package org.usfirst.frc.team6002.robot.commands;

import org.usfirst.frc.team6002.robot.Robot;

import edu.wpi.first.wpilibj.command.CommandGroup;

/**
 *
 */
public class LowBarHighGoal extends CommandGroup {
    
    public  LowBarHighGoal() {
        // Add Commands here:
        // e.g. addSequential(new Command1());
        //      addSequential(new Command2());
        // these will run in order.

        // To run multiple commands at the same time,
        // use addParallel()
        // e.g. addParallel(new Command1());
        //      addSequential(new Command2());
        // Command1 and Command2 will run in parallel.

        // A command group will require all of the subsystems that each member
        // would require.
        // e.g. if Command1 requires chassis, and Command2 requires arm,
        // a CommandGroup containing them would require both the chassis and the
        // arm.
    	/*
    	addSequential(new FullSpeedForward(170,.65,true));//Go thru low bar
    	addSequential(new Turn(90,.55));
    	addSequential(new DriveStraightWithGyro(112, .65,0.02, true)); //Turn toward goal
    	addSequential(new Turn(93, .55));
    	addSequential(new GoToAngle(Robot.pivot.horiOut));
    	addSequential(new TimeDelay(.4));
    	addSequential(new RunCatapult());
    	*/
    	addSequential(new DriveStraightWithGyro(200,.7,0.02,false));//Go thru low bar
    	addSequential(new Turn(53,.65));//Turn toward goal
    	addSequential(new TimeDelay(.5));
    	addSequential(new AutoTarget());
    	addSequential(new GoToAngle(Robot.pivot.vertical));
    	//addSequential(new FullSpeedForward(5,.5,false));
    	addSequential(new TimeDelay(.5));
    	addSequential(new RunCatapult());
    	//addSequential(new FullSpeedForward(100,.6,true));//Go up to low goal
    	//addSequential(new FullSpeedForward(35,.8,true));//Go up to low goal
    	//addSequential(new ReverseIntake());//Spin ball into goal
    	//addSequential(new GoToAngle(Robot.pivot.fourtyFive));//Bring out arm
    	//addSequential(new RunCatapult());//Launch ball
    }
}
