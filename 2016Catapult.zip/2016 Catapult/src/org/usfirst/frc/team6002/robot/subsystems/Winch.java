package org.usfirst.frc.team6002.robot.subsystems;

import org.usfirst.frc.team6002.robot.RobotMap;
import org.usfirst.frc.team6002.robot.commands.WinchRest;

import edu.wpi.first.wpilibj.VictorSP;
import edu.wpi.first.wpilibj.command.PIDSubsystem;



public class Winch extends PIDSubsystem {
	
	public VictorSP lWinch = new VictorSP(RobotMap.lWinch);
	public VictorSP rWinch = new VictorSP(RobotMap.rWinch);
	public static double kP; 
	public static double kI;
	public static double kD; 
	
    // Initialize your subsystem here
    public Winch() {
    	super("winch", kP, kI, kD);
        // Use these to get going:
        // setSetpoint() -  Sets where the PID controller should move the system
        //                  to
        // enable() - Enables the PID controller.
    }
    
    public void initDefaultCommand() {
        // Set the default command for a subsystem here.
        //setDefaultCommand(new MySpecialCommand());
    	setDefaultCommand(new WinchRest());
    }
    
    protected double returnPIDInput() {
        // Return your input value for the PID loop
        // e.g. a sensor, like a potentiometer:
        // yourPot.getAverageVoltage() / kYourMaxVoltage;
    	return 0.0;
    }
    
    protected void usePIDOutput(double output) {
        // Use output to drive your system, like a motor
        // e.g. yourMotor.set(output);
    }
    public void winchRest() {
    	lWinch.set(0);
    	rWinch.set(0);
    }
    public void winchRaise() {
    	lWinch.set(1);
    	rWinch.set(1);
    }
    
    public void winchLower() {
    	lWinch.set(-1);
    	rWinch.set(-1);
    }
}
