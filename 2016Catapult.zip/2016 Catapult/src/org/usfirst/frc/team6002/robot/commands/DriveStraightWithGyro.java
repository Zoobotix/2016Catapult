package org.usfirst.frc.team6002.robot.commands;

import org.usfirst.frc.team6002.robot.Robot;

import edu.wpi.first.wpilibj.command.Command;
import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;

/**
 *
 */
public class DriveStraightWithGyro extends Command {
	double distance;
	double maxSpeed;
	double speed = 0;
	double acceleration;
	double decelSpeed = .4;
	double minDecelDist = 120;
	double slope = (200.0);
	double bIntercept = 90;
	boolean reverse;
	
    public DriveStraightWithGyro(int distanceSet, double speedVal, double accel, boolean dir) {
        // Use requires() here to declare subsystem dependencies
        // eg. requires(chassis);
    	requires(Robot.chassis);
    	distance = distanceSet; 
    	maxSpeed = speedVal;
    	acceleration = accel; 
    	reverse = dir;
    }

    // Called just before this Command runs the first time
    protected void initialize() {
    	Robot.chassis.leftEnc.reset();
    	Robot.chassis.rightEnc.reset();
    	Robot.chassis.setSetpoint(Robot.chassis.gyro.getAngle());
    	Robot.chassis.setPID(0.08, 0, 0);//0.05
    	Robot.chassis.changeRange(1);
    	Robot.chassis.enable();   
    	//System.out.println("Drive straight START");
    	//System.out.println("Drive straight START");
    }

    // Called repeatedly when this Command is scheduled to run
    protected void execute() {
    	//Robot.chassis.driveStraight(distance, maxSpeed, acceleration, reverse);
    	//Accelerate to max speed
    	if(Robot.chassis.getDistance(Robot.chassis.leftEnc) < distance - ((maxSpeed*slope)-bIntercept)){
    		//Accererlate until max speed is reached.
    		if(Math.abs(speed) < maxSpeed){
    			if(reverse){
    				speed-=acceleration;
    			}
    			else{
    				speed+=acceleration;
    			}
    		}
    		//Then hold max speed.
    		else{    			
    			if(reverse){
    				speed=-maxSpeed;
    			}
    			else{
    				speed=maxSpeed;
    			}
    		}
    	}
    	//Decelerate to zero. 
    	else{
    		if(Robot.chassis.getDistance(Robot.chassis.leftEnc) < distance){
    			if(Math.abs(speed) > decelSpeed){
        			if(reverse){
        				speed+=acceleration;
        			}
        			else{
        				speed-=acceleration;
        			}
    			}
    			else{
    				if(reverse){
        				speed=-decelSpeed;
        			}
        			else{
        				speed=decelSpeed;
        			}
    			}
    		}
    		else{
    			speed = 0;
    		}    		
    	}
    	//System.out.println("speed: "+speed + "  set distance: "+distance+"  left enc distance: "+Robot.chassis.getDistance(Robot.chassis.leftEnc));
    	//SmartDashboard.putNumber("Left Enc Count", Math.abs(Robot.chassis.leftEnc.get()));
    	//SmartDashboard.putNumber("Right Enc Count", Math.abs(Robot.chassis.rightEnc.get()));
    	//SmartDashboard.putNumber("Straight PID Output", Robot.chassis.getPidOutput());
    	//SmartDashboard.putNumber("Error", Math.abs(Robot.chassis.leftEnc.get())-Math.abs(Robot.chassis.rightEnc.get()));
    	Robot.chassis.setDriveOutput(speed);
    }

    // Make this return true when this Command no longer needs to run execute()
    protected boolean isFinished() {
        return Robot.chassis.getDistance(Robot.chassis.leftEnc)>=distance;
    }

    // Called once after isFinished returns true
    protected void end() {
    	System.out.println("Drive straight END");
    	System.out.println("Left enc: "+Robot.chassis.getDistance(Robot.chassis.leftEnc));
    	Robot.chassis.disable();
    }

    // Called when another command which requires one or more of the same
    // subsystems is scheduled to run
    protected void interrupted() {
    	Robot.chassis.disable();
    }
    
}
