package org.usfirst.frc.team6002.robot.commands;

import org.usfirst.frc.team6002.robot.Robot;

import edu.wpi.first.wpilibj.command.CommandGroup;
import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;

/**
 *
 */
public class GateAuto extends CommandGroup {
    
    public  GateAuto() {
        // Add Commands here:
        // e.g. addSequential(new Command1());
        //      addSequential(new Command2());
        // these will run in order.

        // To run multiple commands at the same time,
        // use addParallel()
        // e.g. addParallel(new Command1());
        //      addSequential(new Command2());
        // Command1 and Command2 will run in parallel.

        // A command group will require all of the subsystems that each member
        // would require.
        // e.g. if Command1 requires chassis, and Command2 requires arm,
        // a CommandGroup containing them would require both the chassis and the
        // arm.
    	//int robotPos=(int) SmartDashboard.getNumber("Robot Position",0);
    	//Get robot position variable from smart dashboard
    	addSequential(new GoToAngle(Robot.pivot.fourtyFive));
    	addSequential(new DriveStraightWithGyro(60,.5,0.02,true));//61
    	//drives in front of the Gate
    	//arm goes under the gate
    	//addSequential(new DriveStraightWithGyro(0,0.5,0,true));
    	//drives intake arm under gate
    	addSequential(new GoToAngle(Robot.pivot.home));
    	addSequential(new DriveStraightWithGyro(60,.6,0.02,true));
    	//addSequential(new DriveStraightWithGyro(60,0.5,0.02,true));
    	addSequential(new Turn(50,.65));//50
    	//addSequential(new DriveStraightWithGyro(50,0.7,0.02,true));
    	addSequential(new FullSpeedForward(40,.6,true));
    	addSequential(new FullSpeedForward(50,.8,true));
    	addSequential(new ReverseIntake());
    	//addSequential(new DriveStraightWithGyro(10,.7,.02,true));
    	/*//Lift gate
    	addSequential(new DriveStraightWithGyro(0,0.5,0,true));
    	//Drive under gate
    	if (robotPos==2){
    		addSequential(new Turn(90,.5));
    		//turns the robot to the right
    		addSequential(new DriveStraightWithGyro(0,.5,0,true));
    		//drives the robot in front of the third barrier
    		addSequential(new Turn(-90,.5));
    		//turns the robot to the left
    		addSequential(new RunCatapult());
    		//shoot
    	}
    	else if(robotPos == 3){
    		addSequential(new RunCatapult());
    		//shoots
    	}
    	else if(robotPos==4){
    		addSequential(new Turn(-90,.5));
    		//turns left
    		addSequential(new DriveStraightWithGyro(0,0.5,0,true));
    		//drives to the third barrier
    		addSequential(new Turn(90,.5));
    		//turns right
    		addSequential(new RunCatapult());
    		//shoots
    	}
    	else if(robotPos == 5){
    		addSequential(new Turn(-90,.5));
    		//turns left
    		addSequential(new DriveStraightWithGyro(0,0.5,0,true));
    		//drives to the fourth barrier
    		addSequential(new DriveStraightWithGyro(0,0.5,0,true));
    		//drives to the third barrier
    		addSequential(new Turn(90,.5));
    		//turns right
    		addSequential(new RunCatapult());
    		//shoots
    	}*/
    }
}
