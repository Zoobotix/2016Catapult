package org.usfirst.frc.team6002.robot;

import edu.wpi.first.wpilibj.buttons.Button;

public class ShiftClick extends Button{
	Button button1, button2;
	public ShiftClick(Button but1, Button but2){
		button1 = but1;
		button2 = but2;
	}
	@Override
	public boolean get() {
		// TODO Auto-generated method stub
		return button1.get() && button2.get();
	}
}
