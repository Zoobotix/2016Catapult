package org.usfirst.frc.team6002.robot.commands;

import org.usfirst.frc.team6002.robot.Robot;

import edu.wpi.first.wpilibj.command.CommandGroup;
import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;

/**
 *
 */
public class TTAuto extends CommandGroup {
    
    public  TTAuto() {
        // Add Commands here:
        // e.g. addSequential(new Command1());
        //      addSequential(new Command2());
        // these will run in order.

        // To run multiple commands at the same time,
        // use addParallel()
        // e.g. addParallel(new Command1());
        //      addSequential(new Command2());
        // Command1 and Command2 will run in parallel.

        // A command group will require all of the subsystems that each member
        // would require.
        // e.g. if Command1 requires chassis, and Command2 requires arm,
        // a CommandGroup containing them would require both the chassis and the
        // arm.
    	//int robotPos=(int) SmartDashboard.getNumber("Robot Position",0);
    	//System.out.println("Robot pos: "+robotPos);
    	//sets up the Smart Dashboard
    	addSequential(new DriveStraightWithGyro(48,.5,0.02,true));
    	//drives in front of the TT
    	addSequential(new GoToAngle(Robot.pivot.fourtyFive));
    	//lowers TT
    	addSequential(new FullSpeedForward(10,.6,true));
    	addSequential(new GoToAngle(Robot.pivot.home));
    	addSequential(new DriveStraightWithGyro(80,0.7,0.02,true));
    	//drives through the
    	/*
    	if (robotPos==2){
    		addSequential(new Turn(90,.5));
    		//turns the robot to the right
    		addSequential(new DriveStraightWithGyro(0,.5,0,true));
    		//drives the robot in front of the third barrier
    		addSequential(new Turn(-90,.5));
    		//turns the robot to the left
    		addSequential(new RunCatapult());
    		//shoot
    	}
    	else if(robotPos == 3){
    		addSequential(new RunCatapult());
    		//shoots
    	}
    	else if(robotPos==4){
    		addSequential(new Turn(-90,.5));
    		//turns left
    		addSequential(new DriveStraightWithGyro(0,0.5,0,true));
    		//drives to the third barrier
    		addSequential(new Turn(90,.5));
    		//turns right
    		addSequential(new RunCatapult());
    		//shoots
    	}
    	else if(robotPos == 5){
    		addSequential(new Turn(-90,.5));
    		//turns left
    		addSequential(new DriveStraightWithGyro(0,0.5,0,true));
    		//drives to the fourth barrier
    		addSequential(new DriveStraightWithGyro(0,0.5,0,true));
    		//drives to the third barrier
    		addSequential(new Turn(90,.5));
    		//turns right
    		addSequential(new RunCatapult());
    		//shoots
    	}
    	*/
    }
}
