package org.usfirst.frc.team6002.robot.commands;

import org.usfirst.frc.team6002.robot.Robot;

import edu.wpi.first.wpilibj.command.Command;
import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;

/**
 *
 */
public class FullSpeedForward extends Command {
	double distance;
	double maxSpeed;
	double speed = 0;
	double acceleration;
	double decelSpeed = .4;
	boolean reverse;
	
    public FullSpeedForward(double distanceSet, double speedVal, boolean dir) {
        // Use requires() here to declare subsystem dependencies
        // eg. requires(chassis);
    	requires(Robot.chassis);
    	distance = distanceSet; 
    	maxSpeed = speedVal;
    	acceleration = .02; 
    	reverse = dir;
    }

    // Called just before this Command runs the first time
    protected void initialize() {
    	Robot.chassis.leftEnc.reset();
    	Robot.chassis.rightEnc.reset();
    	Robot.chassis.setSetpoint(Robot.chassis.gyro.getAngle());
    	Robot.chassis.setPID(0.05, 0, 0);
    	Robot.chassis.changeRange(.5);
    	Robot.chassis.enable(); 
    }

    // Called repeatedly when this Command is scheduled to run
    protected void execute() {
    	if(Robot.chassis.getDistance(Robot.chassis.leftEnc) < distance){
    		//Accererlate until max speed is reached.
    		if(Math.abs(speed) < maxSpeed){
    			if(reverse){
    				speed-=acceleration;
    			}
    			else{
    				speed+=acceleration;
    			}
    		}
    		//Then hold max speed.
    		else{    			
    			if(reverse){
    				speed=-maxSpeed;
    			}
    			else{
    				speed=maxSpeed;
    			}
    		}
    	}
    	//Decelerate to zero. 
    	else{
    		/*
    		if(Robot.chassis.getDistance(Robot.chassis.leftEnc) < distance){
    			if(Math.abs(speed) > decelSpeed){
        			if(reverse){
        				speed+=acceleration;
        			}
        			else{
        				speed-=acceleration;
        			}
    			}
    			else{
    				if(reverse){
        				speed=-decelSpeed;
        			}
        			else{
        				speed=decelSpeed;
        			}
    			}
    		}
    		else{
    			
    		}  
    		*/  
    		speed = 0;
    	}
    	//System.out.println("speed: "+speed + "  set distance: "+distance+"  left enc distance: "+Robot.chassis.getDistance(Robot.chassis.leftEnc));
    	//SmartDashboard.putNumber("Left Enc Count", Math.abs(Robot.chassis.leftEnc.get()));
    	//SmartDashboard.putNumber("Right Enc Count", Math.abs(Robot.chassis.rightEnc.get()));
    	//SmartDashboard.putNumber("Straight PID Output", Robot.chassis.getPidOutput());
    	//SmartDashboard.putNumber("Error", Math.abs(Robot.chassis.leftEnc.get())-Math.abs(Robot.chassis.rightEnc.get()));
    	System.out.println("Full speed: "+speed);
    	//Robot.chassis.roboDrive.arcadeDrive(0, Robot.chassis.pidOutput);
    	Robot.chassis.setDriveOutput(speed);
    }

    // Make this return true when this Command no longer needs to run execute()
    protected boolean isFinished() {
        return Robot.chassis.getDistance(Robot.chassis.leftEnc)>=distance;
    }

    // Called once after isFinished returns true
    protected void end() {
    	System.out.println("Drive straight END");
    	System.out.println("Left enc: "+Robot.chassis.getDistance(Robot.chassis.leftEnc));
    	Robot.chassis.disable();
    }

    // Called when another command which requires one or more of the same
    // subsystems is scheduled to run
    protected void interrupted() {
    	Robot.chassis.disable();
    }
}
