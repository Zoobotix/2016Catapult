
package org.usfirst.frc.team6002.robot;

import edu.wpi.first.wpilibj.IterativeRobot;
import edu.wpi.first.wpilibj.command.Command;
import edu.wpi.first.wpilibj.command.Scheduler;
import edu.wpi.first.wpilibj.command.Subsystem;
import edu.wpi.first.wpilibj.livewindow.LiveWindow;
import edu.wpi.first.wpilibj.networktables.NetworkTable;

import org.usfirst.frc.team6002.robot.commands.*;
import org.usfirst.frc.team6002.robot.subsystems.Catapult;
import org.usfirst.frc.team6002.robot.subsystems.Chassis;
import org.usfirst.frc.team6002.robot.subsystems.Intake;
import org.usfirst.frc.team6002.robot.subsystems.IntakePivot;
import org.usfirst.frc.team6002.robot.subsystems.Winch;

import edu.wpi.first.wpilibj.smartdashboard.SendableChooser;
import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;
/**		
 * The VM is configured to automatically run this class, and to call the
 * functions corresponding to each mode, as described in the IterativeRobot
 * documentation. If you change the name of this class or the package after
 * creating this project, you must also update the manifest file in the resource
 * directory.
 */
	public class Robot extends IterativeRobot {
	public static final Intake intake = new Intake();
	public static IntakePivot pivot;	
    public static final Catapult catapult = new Catapult(); 
    public static final Winch winch = new Winch();
    public static final Chassis chassis = new Chassis(); 
	public static OI oi;
	//public static double[] centerX;
	public static double goalCenterX;
	double[] defaultValue = new double[0];
	//NetworkTable table;
	String autoSelected;
    Command autonomousCommand;
    SendableChooser chooser;

    /**
     * This function is run when the robot is first started up and should be0o
     * used for any initialization code.
     */
    public void robotInit() {
    	//table = NetworkTable.getTable("GRIP/HighGoalData");
    	pivot = new IntakePivot();
    	System.out.println("Init pivot obj");
    	pivot.init();
    	pivot.setAngle(pivot.pivotMotor.getPosition());
		oi = new OI();

		/*
        chooser = new SendableChooser();
        chooser.addDefault("Low Bar", new AutoLowBar());
        chooser.addObject("Totter", new AutoTotterBarrier());
        chooser.addObject("Gate", new AutoGateOpener()); 
        */
    }
	
	/**
     * This function is called once each time the robot enters Disabled mode.
     * You can use it to reset any subsystem information you want to clear when
	 * the robot is disabled.
     */
    public void disabledInit(){
    	Robot.chassis.resetEncoders();
    	//System.out.println(pivot.pivotMotor.get());
    }
	
	public void disabledPeriodic() {
		SmartDashboard.putNumber("Left Drive Side", chassis.leftMotor.get());
    	SmartDashboard.putNumber("Right Drive Side", chassis.rightMotor.get());
    	SmartDashboard.putNumber("Left Encoder Count", chassis.getDistance(chassis.leftEnc));
    	SmartDashboard.putNumber("Right Encoder Count", chassis.getDistance(chassis.rightEnc));
    	SmartDashboard.putNumber("Gyro Angle", chassis.gyro.getAngle());
    	SmartDashboard.putBoolean("Catapult", catapult.digital.get());
    	SmartDashboard.putNumber("Arm Home Pos", pivot.home);
		SmartDashboard.putNumber("Arm Horizontal", pivot.horiOut);
		SmartDashboard.putNumber("Arm 45", pivot.fourtyFive);
		SmartDashboard.putString("DB/String 0", SmartDashboard.getString("Auto Selector","Do Nothing"));
		autoSelected = SmartDashboard.getString("Auto Selector", "Do Nothing");
		Scheduler.getInstance().run();
	}

	/**
	 * This autonomous (along with the chooser code above) shows how to select between different autonomous modes
	 * using the dashboard. The sendable chooser code works with the Java SmartDashboard. If you prefer the LabVIEW
	 * Dashboard, remove all of the chooser code and uncomment the getString code to get the auto name from the text box
	 * below the Gyro
	 *
	 * You can add additional auto modes by adding additional commands to the chooser code above (like the commented example)
	 * or additional comparisons to the switch structure below with additional strings & commands.
	 */
    public void autonomousInit() {
    	//autoSelected = SmartDashboard.getString("Auto Selector", "Do Nothing");
    	System.out.println(autoSelected);
        //autonomousCommand = new AutoGateHighGoal();
        		//new SampleAuto();
        		//(Command) chooser.getSelected();
    	//autoSelected = SmartDashboard.getString("Auto Selector", "Do Nothing");
		switch(autoSelected) {
		case "Low Bar High Goal":
			autonomousCommand = new LowBarHighGoal();
			break;
		case "Low Bar Low Goal":
			autonomousCommand = new LowBarLowGoal();
			break;
		case "Cheval de Frise":
			autonomousCommand = new TTAuto();
			break;
		case "Gate":
			autonomousCommand = new GateAuto();
			break;
		case "Simple Break Barrier":
			System.out.println("Run simple break barrier");
			autonomousCommand = new SBBarrier();
			break;
		case "Do Nothing":
			autonomousCommand = null;
			break;
		default:
			autonomousCommand = null;
			break;
		} 
		
    	//autonomousCommand = new AutoSpybot();
		if (autonomousCommand != null) autonomousCommand.start();
    }

    /**
     * This function is called periodically during autonomous
     */
    public void autonomousPeriodic() {
    	SmartDashboard.putNumber("Left Drive Side", chassis.leftMotor.get());
    	SmartDashboard.putNumber("Right Drive Side", chassis.rightMotor.get());
    	SmartDashboard.putNumber("Left Encoder Count", chassis.getDistance(chassis.leftEnc));
    	SmartDashboard.putNumber("Right Encoder Count", chassis.getDistance(chassis.rightEnc));
    	SmartDashboard.putNumber("Gyro Angle", chassis.gyro.getAngle());
    	SmartDashboard.putBoolean("Catapult", catapult.digital.get());
        Scheduler.getInstance().run();
    }

    public void teleopInit() {
		// This makes sure that the autonomous stops running when
        // teleop starts running. If you want the autonomous to 
        // continue until interrupted by another command, remove
        // this line or comment it out.
    	pivot.setAngle(pivot.pivotMotor.getPosition());
        if (autonomousCommand != null) autonomousCommand.cancel();
    }

    /**
     * This function is called periodically during operator control
     */
    public void teleopPeriodic() {
    	//double[] centerX = table.getNumberArray("centerX",defaultValue);
    	//SmartDashboard.putNumber("DB/Slider 1",centerX[0]);
    	//goalCenterX = centerX[0];
    	//double[] centerY = table.getNumberArray("centerY",defaultValue);
    	//System.out.println(Robot.catapult.digital.get());
    	//System.out.println("Left enc: "+chassis.getDistance(chassis.leftEnc)+"Right Enc: "+chassis.getDistance(chassis.rightEnc));
    	//SmartDashboard.putData("Auto mode", chooser);
    	SmartDashboard.putNumber("Left Drive Side", chassis.leftMotor.get());
    	SmartDashboard.putNumber("Right Drive Side", chassis.rightMotor.get());
    	SmartDashboard.putNumber("Left Encoder Count", chassis.getDistance(chassis.leftEnc));
    	SmartDashboard.putNumber("Right Encoder Count", chassis.getDistance(chassis.rightEnc));
    	SmartDashboard.putNumber("Gyro Angle", chassis.gyro.getAngle());
    	SmartDashboard.putBoolean("Catapult", catapult.digital.get());
    	//SmartDashboard.putNumber("DB/Slider 0", Math.abs(chassis.rightEnc.get()));
    	//SmartDashboard.putNumber("DB/Slider 1", Math.abs(chassis.leftEnc.get()));
    	//comment
        SmartDashboard.putData(catapult);
        SmartDashboard.putData(chassis);
        SmartDashboard.putData(intake);
        SmartDashboard.putData(pivot);
    	
    	/*
    	SmartDashboard.putNumber("Chassis Gyro Angle", chassis.gyro.getAngle());
    	SmartDashboard.putNumber("Chassis Gyro Yaw", chassis.gyro.getYaw());
    	SmartDashboard.putNumber("Chassis PID Output", chassis.getPidOutput());
    	SmartDashboard.putNumber("Chassis Left Encoder Count", Math.abs(chassis.leftEnc.get()));
    	*/
    	//comment2
    	SmartDashboard.putNumber("Chassis Gyro Angle", chassis.gyro.getAngle());
    	SmartDashboard.putNumber("Chassis Gyro Yaw", chassis.gyro.getYaw());
    	SmartDashboard.putNumber("Chassis PID Output", chassis.getPidOutput());
    	SmartDashboard.putNumber("Chassis Left Encoder Count", Math.abs(chassis.leftEnc.get()));
    	
    	SmartDashboard.putNumber("Chassis Left Distance Travelled", chassis.getDistance(chassis.leftEnc));
    	SmartDashboard.putNumber("Chassis Right Distance Travelled", chassis.getDistance(chassis.rightEnc));
    	SmartDashboard.putNumber("Chassis Drive Output", chassis.driveOutput);
    	SmartDashboard.putNumber("Chassis P Value", chassis.getPVal());
    	SmartDashboard.putNumber("Chassis I Value", chassis.getIVal());
    	SmartDashboard.putNumber("Chassis D Value", chassis.getDVal());
    	
    	SmartDashboard.putNumber("Pivot Angle", pivot.pivotMotor.get());
    	SmartDashboard.putNumber("Pivot Setpoint", pivot.pivotMotor.getSetpoint());
    	
    	SmartDashboard.putBoolean("Catapult Switch", Robot.catapult.digital.get());
    	
    	
    	//SmartDashboard.putNumber("Center Y",centerY[0]);
    	//SmartDashboard.putData(Scheduler.getInstance());
        Scheduler.getInstance().run();
    }
    
    /**
     * This function is called periodically during test mode
     */
    public void testPeriodic() {
        LiveWindow.run();
    }
}
