package org.usfirst.frc.team6002.robot.subsystems;

import org.usfirst.frc.team6002.robot.RobotMap;
import org.usfirst.frc.team6002.robot.commands.PivotRest;

import edu.wpi.first.wpilibj.CANTalon;
import edu.wpi.first.wpilibj.CANTalon.FeedbackDevice;
import edu.wpi.first.wpilibj.CANTalon.TalonControlMode;
import edu.wpi.first.wpilibj.Encoder;
import edu.wpi.first.wpilibj.VictorSP;
import edu.wpi.first.wpilibj.command.PIDSubsystem;
import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;

/**
 *
 */
public class IntakePivot extends PIDSubsystem {
	private static double kP = 0; 
	private static double kI = 0; 
	private static double kD = 0;
	private double maxRange = 1;
	private static double setpoint = 0;
	private static double angleScale = 360.0/497.0;
	//Determined setpoints. To access these variables in another class, use Robot.pivot.(variable name)
	public static double home;//Cradle
	public static double horiOut;//Horizontal out - used for intaking balls
	public static double fourtyFive;//Touching ground
	public static double vertical;
	
	Encoder enc = new Encoder(RobotMap.intakeA,RobotMap.intakeB,true);
	public CANTalon pivotMotor = new CANTalon(1);
	
    // Initialize your subsystem here
    public IntakePivot() {
        // Use these to get going:
        // setSetpoint() -  Sets where the PID controller should move the system
        //                  to
        // enable() - Enables the PID controller.
    	super("pivot", kP, kI, kD);
    }
    
    public void initDefaultCommand() {
        // Set the default command for a subsystem here.
        setDefaultCommand(new PivotRest());
    }
    
    protected double returnPIDInput() {
        // Return your input value for the PID loop
        // e.g. a sensor, like a potentiometer:
        // yourPot.getAverageVoltage() / kYourMaxVoltage;
    	return 0.0; 
    }
    
    protected void usePIDOutput(double output) {
        // Use output to drive your system, like a motor
        // e.g. yourMotor.set(output);
    	//intakeMotor.set(output); 
    }
    public void setAngle(double setpoint){//Set the setpoint
    	pivotMotor.set(setpoint);
    }
    public void init(){
    	/*
    	 * Run at boot up. This takes the current position of the ABSOLUTE encoder and set the RELATIVE encoder to it.
    	 * This allows the encoder to use absolute positioning(seeding)
    	 *
    	/* lets grab the 360 degree position of the MagEncoder's absolute position */
    	int absPos = pivotMotor.getPulseWidthPosition() & 0xFFF;
		pivotMotor.setEncPosition(absPos);/* use the low level API to set the quad encoder signal */
		System.out.println("Abs Pos: "+absPos);
		pivotMotor.setFeedbackDevice(FeedbackDevice.CtreMagEncoder_Relative); //Set the feedback device that is hooked up to the talon
		
		//Configuring the PID and Talon settings
		pivotMotor.setSafetyEnabled(false);//Turn off safety features.
		pivotMotor.enableBrakeMode(true);//Enable brake mode on talon
		pivotMotor.changeControlMode(TalonControlMode.Position); //Change control mode of talon, default is PercentVbus (-1.0 to 1.0)
		pivotMotor.configPeakOutputVoltage(+8f, -8f);//Voltage range for PID
		
		pivotMotor.setAllowableClosedLoopErr(0);//The allowed margin of error.
		pivotMotor.setProfile(0);//The PID profile found on the roborio web interface
		pivotMotor.setPID(0.5, 0, 0.0); //Set the PID constants (p, i, d)
		
		home = 0.860;//pivotMotor.getPosition();
		horiOut = home - .41;//.37;
		vertical = home - .246;
		fourtyFive = home - 0.52;
		//Print out data to dashboard
		SmartDashboard.putNumber("Arm Home Pos", home);
		SmartDashboard.putNumber("Arm Horizontal", horiOut);
		SmartDashboard.putNumber("Arm 45", fourtyFive);
		System.out.println("Home: "+home);
		System.out.println("Horizontal Out: "+horiOut);
    }
}
