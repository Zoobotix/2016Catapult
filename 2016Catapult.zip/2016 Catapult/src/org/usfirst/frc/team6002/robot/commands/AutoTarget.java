package org.usfirst.frc.team6002.robot.commands;

import org.usfirst.frc.team6002.robot.Robot;

import edu.wpi.first.wpilibj.Timer;
import edu.wpi.first.wpilibj.command.Command;
import edu.wpi.first.wpilibj.networktables.NetworkTable;
import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;

/**
 *
 */
public class AutoTarget extends Command {
	NetworkTable table;
	double[] defaultValue = new double[0];
	double slope = (9.0/50.0);
	double speed = .5;
	double targetXPos = 313;
	double initXPos;
	double angle;
	double pixelDifference;
	boolean stop;
	
    public AutoTarget() {
        // Use requires() here to declare subsystem dependencies
        // eg. requires(chassis);
    	requires(Robot.chassis);
    }

    // Called just before this Command runs the first time
    protected void initialize() {
    	table = NetworkTable.getTable("GRIP/HighGoalData");
    	double[] centerX = table.getNumberArray("centerX",defaultValue);
    	initXPos = centerX[0];
    	pixelDifference = targetXPos - initXPos;
    	//System.out.println("CenterX: "+ currentGoalXPos);
    	System.out.println("Current X Center: "+initXPos);
    	
    	angle = -(pixelDifference*.11);
    	System.out.println("Degree: "+angle);
    	System.out.println("Angle: "+angle);
    	System.out.println("Pixel Difference: " + pixelDifference);
    	System.out.println("Init gyro pos; "+Robot.chassis.gyro.getAngle());
    	SmartDashboard.putNumber("DB/Slider 2", targetXPos);
    	SmartDashboard.putNumber("DB/Slider 1", initXPos);
    	SmartDashboard.putNumber("DB/Slider 0", angle);
    	SmartDashboard.putNumber("DB/Slider 3", Robot.chassis.gyro.getAngle());
    	Robot.chassis.spinInPlace(angle, .5);
    	stop = false;
    }

    // Called repeatedly when this Command is scheduled to run
    protected void execute() {
    	//System.out.println("Calc Spin: "+-calcOffsetDegrees());

    	//currentGoalXPos = SmartDashboard.getNumber("DB/Slider 1");
    	//System.out.println("Current X Pos"+currentGoalXPos);
    	stop = true;
    }

    // Make this return true when this Command no longer needs to run execute()
    protected boolean isFinished() {
        return true;
    }

    // Called once after isFinished returns true
    protected void end() {
    }

    // Called when another command which requires one or more of the same
    // subsystems is scheduled to run
    protected void interrupted() {
    }
    /*
    private double calcOffsetDegrees(){
    	double errorPixel = targetXPos - initXPos;
    	System.out.println("Error Pixel: "+errorPixel);
    	return errorPixel * slope;
    }
    */
}
