package org.usfirst.frc.team6002.robot.commands;

import org.usfirst.frc.team6002.robot.Robot;

import edu.wpi.first.wpilibj.command.CommandGroup;

/**
 *
 */
public class AutoTTHighGoal extends CommandGroup {
    
    public  AutoTTHighGoal() {
        // Add Commands here:
        // e.g. addSequential(new Command1());
        //      addSequential(new Command2());
        // these will run in order.

        // To run multiple commands at the same time,
        // use addParallel()
        // e.g. addParallel(new Command1());
        //      addSequential(new Command2());
        // Command1 and Command2 will run in parallel.

        // A command group will require all of the subsystems that each member
        // would require.
        // e.g. if Command1 requires chassis, and Command2 requires arm,
        // a CommandGroup containing them would require both the chassis and the
        // arm.
    	addSequential(new DriveStraightWithGyro(48,.5,0.02,true));
    	//drives in front of the TT
    	addSequential(new GoToAngle(Robot.pivot.fourtyFive));
    	//lowers TT
    	addSequential(new FullSpeedForward(10,.6,true));
    	addSequential(new GoToAngle(Robot.pivot.home));
    	addSequential(new DriveStraightWithGyro(80,0.7,0.02,true));
    	addSequential(new DriveStraightWithGyro(60,0.7,0.02,true));
    	addSequential(new Turn(45,.65));
    	addSequential(new DriveStraightWithGyro(90,0.7,0.02,true));
    	addSequential(new FullSpeedForward(10,.5,true));
    	addSequential(new ReverseIntake());
    }
}
