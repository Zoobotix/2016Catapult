package org.usfirst.frc.team6002.robot;

import edu.wpi.first.wpilibj.Joystick;
import edu.wpi.first.wpilibj.buttons.Button;
import edu.wpi.first.wpilibj.buttons.JoystickButton;

import org.usfirst.frc.team6002.robot.commands.*;

/**
 * This class is the glue that binds the controls on the physical operator
 * interface to the commands and command groups that allow control of the robot.
 */
public class OI {
    //// CREATING BUTTONS
    // One type of button is a joystick button which is any button on a joystick.
    // You create one by telling it which joystick it's on and which button
    // number it is.
    // Joystick stick = new Joystick(port);
    // Button button = new JoystickButton(stick, buttonNumber);
    
    // There are a few additional built in buttons you can use. Additionally,
    // by subclassing Button you can create custom triggers and bind those to
    // commands the same as any other Button.
    
    //// TRIGGERING COMMANDS WITH BUTTONS
    // Once you have a button, it's trivial to bind it to a button in one of
    // three ways:
    
    // Start the command when the button is pressed and let it run the command
    // until it is finished as determined by it's isFinished method.
    // button.whenPressed(new ExampleCommand());
    
    // Run the command while the button is being held down and interrupt it once
    // the button is released.
    // button.whileHeld(new ExampleCommand())
    
    // Start the command when the button is released  and let it run the command
    // until it is finished as determined by it's isFinished method.
    // button.whenReleased(new ExampleCommand());
	public static Joystick joy = new Joystick(0);
	public static Joystick coJoy = new Joystick(1);
	public double getLeftYAxis(){
		return -joy.getRawAxis(1);
	}
	public double getRightYAxis(){
		return -joy.getRawAxis(5);
	}
	public double getRightXAxis(){
		return joy.getRawAxis(4);
	}
	
	Button aButton = new JoystickButton(joy, 1);
	Button bButton = new JoystickButton(joy, 2);
	Button rightBumper = new JoystickButton(joy, 6); 
	Button leftBumper = new JoystickButton(joy, 5);
	Button xButton = new JoystickButton(joy,3);
	Button yButton = new JoystickButton(joy,4);
	
	JoystickAnalogButton leftTrig = new JoystickAnalogButton(joy, 2, 0.5);
	JoystickAnalogButton rightTrig = new JoystickAnalogButton(joy, 3, 0.5);
	ShiftClick leftBumperButtonX = new ShiftClick(new JoystickButton(coJoy, 5), new JoystickButton(coJoy, 3));
	ShiftClick leftBumperButtonA = new ShiftClick(new JoystickButton(coJoy, 5), new JoystickButton(coJoy, 1));
	ShiftClick leftBumperButtonB = new ShiftClick(new JoystickButton(coJoy, 5), new JoystickButton(coJoy, 2));
	ShiftClick leftBumperButtonY = new ShiftClick(new JoystickButton(coJoy, 5), new JoystickButton(coJoy, 4));
	Button coAButton = new JoystickButton(coJoy,1);
	Button coBButton = new JoystickButton(coJoy,2);
	Button coXButton = new JoystickButton(coJoy,3);
	Button coYButton = new JoystickButton(coJoy,4);
	Button coRightBumper = new JoystickButton(coJoy, 6);
	//XboxController control = new XboxController(1);
	
	public OI(){
		//Primary joystick controls
		//rightTrig.whenPressed(new RunCatapult()); 
		//leftTrig.whenPressed(new AutoTarget()); 
		//rightBumper.toggleWhenPressed(new ToggleAngle(Robot.pivot.horiOut,Robot.pivot.home));	
		//leftBumper.toggleWhenPressed(new BallIntake());
		//aButton.whenPressed(new GoToAngle(Robot.pivot.fourtyFive));
		//bButton.whenPressed(new AutoTarget());
		//xButton.whenPressed(new GoToAngle(Robot.pivot.vertical));
		//aButton.whenPressed(new Turn(.5,.7));	
		//yButton.toggleWhenPressed(new TeleopReverseIntake());
		
		//Co op joystick controls
		//coAButton.whenPressed(new TeleopTT());
		//coBButton.whenPressed(new TeleopSallyPort());
		//coXButton.whenPressed(new TeleopLowBar());
		//coYButton.whenPressed(new TeleopLowBarAcross());
		//coRightBumper.whenPressed(new TeleopGate());
	}
	public boolean getLeftTrig(){
		return leftTrig.get(); 
	}
}

