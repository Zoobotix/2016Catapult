package org.usfirst.frc.team6002.robot.commands;

import org.usfirst.frc.team6002.robot.Robot;

import edu.wpi.first.wpilibj.Timer;
import edu.wpi.first.wpilibj.command.Command;
import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;

/**
 *get a life kevin L2 brush ur teeth
 */
public class RunCatapult extends Command {
	boolean low; 
	boolean high;
	boolean end; 
	boolean currentState;
	double speed = -.9;
	
    public RunCatapult() {
        // Use requires() here to declare subsystem dependencies
        // eg. requires("chassis");
    	requires(Robot.catapult); 
    }

    // Called just before this Command runs the first time
    protected void initialize() {
    	low = false;
    	high = false;
    	end = false;
    }

    // Called repeatedly when this Command is scheduled to run
    protected void execute() {
    	currentState = Robot.catapult.digital.get();
    	//SmartDashboard.putBoolean("Catapult LOW Value", low);
    	//SmartDashboard.putBoolean("Catapult HIGH Value", high);
    	Robot.catapult.running = true;
    	if(currentState && low == true){
    		Robot.catapult.shootSpeed(0);
    	    end = true; 
    	} 
    	else if(currentState == false && low == false){
    		low = true; 
    		Robot.catapult.shootSpeed(speed); 
    	}
    	else{
    		Robot.catapult.shootSpeed(speed);
    	}
    	
    	if(currentState == true && high == false){
    		high = true;
    	}
    	else if(currentState == false && high == true){
    		//Timer.delay(.75);
    		System.out.println("Delaying for 2");
    		Robot.catapult.shootSpeed(0); 
    		Timer.delay(.5);
    		high = false;
    		System.out.println("Done delaying for 2");
    		Robot.catapult.shootSpeed(speed);
    	}
    	
       //System.out.println(Robot.catapult.digital.get() + " " + low + " " + end);
    	
    }

    // Make this return true when this Command no longer needs to run execute()
    protected boolean isFinished() {
        return end;
    }

    // Called once after isFinished returns true
    protected void end() {
    	Robot.catapult.running = false;
    	System.out.println("DONE");
    	Robot.catapult.shootSpeed(0); 
    }

    // Called when another command which requires one or more of the same
    // subsystems is scheduled to run
    protected void interrupted() {
    	Robot.catapult.shootSpeed(0);
    }
}
