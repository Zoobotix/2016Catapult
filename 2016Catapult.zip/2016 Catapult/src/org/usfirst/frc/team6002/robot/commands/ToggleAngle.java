package org.usfirst.frc.team6002.robot.commands;

import org.usfirst.frc.team6002.robot.Robot;

import edu.wpi.first.wpilibj.command.Command;
import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;

/**
 *
 */
public class ToggleAngle extends Command {
	double targetAngle,returnAngle;
	//Target angle is the angle you want to go when you press
	//button the first time and the return angle is the angle
	//you want to return to when you press the same button again.
	
    public ToggleAngle(double targetSetpoint, double returnSetpoint) {
        // Use requires() here to declare subsystem dependencies
        // eg. requires(chassis);
    	requires(Robot.pivot);
    	targetAngle = targetSetpoint;
    	returnAngle = returnSetpoint;
    }

    // Called just before this Command runs the first time
    protected void initialize() {
    	SmartDashboard.putBoolean("Arm Home", false);
    	Robot.pivot.setAngle(targetAngle);
    }

    // Called repeatedly when this Command is scheduled to run
    protected void execute() {
    }

    // Make this return true when this Command no longer needs to run execute()
    protected boolean isFinished() {
        return false;
    }

    // Called once after isFinished returns true
    protected void end() {
    }

    // Called when another command which requires one or more of the same
    // subsystems is scheduled to run
    protected void interrupted() {
    	SmartDashboard.putBoolean("Arm Home", true);
    	//only home when the catapult is not running to prevent deadly collision.
    	Robot.pivot.setAngle(returnAngle);
    }
}
