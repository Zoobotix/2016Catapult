package org.usfirst.frc.team6002.robot.subsystems;
@
import org.usfirst.frc.team6002.robot.Robot;
import org.usfirst.frc.team6002.robot.RobotMap;
import org.usfirst.frc.team6002.robot.commands.AutoRoom;
import org.usfirst.frc.team6002.robot.commands.DriveStraightWithGyro;
import org.usfirst.frc.team6002.robot.commands.DriveWithJoystick;

import edu.wpi.first.wpilibj.ADXRS450_Gyro;
import edu.wpi.first.wpilibj.Encoder;
import edu.wpi.first.wpilibj.PIDController;
import edu.wpi.first.wpilibj.PIDOutput;
import edu.wpi.first.wpilibj.RobotDrive;
import edu.wpi.first.wpilibj.SPI;
import edu.wpi.first.wpilibj.Talon;
import edu.wpi.first.wpilibj.Timer;
import edu.wpi.first.wpilibj.VictorSP;
import edu.wpi.first.wpilibj.command.PIDSubsystem;
import edu.wpi.first.wpilibj.networktables.NetworkTable;
import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;
import com.kauailabs.navx.frc.AHRS;

/**
 *
 */
public class Chassis extends PIDSubsystem {
	public VictorSP leftMotor=new VictorSP(RobotMap.leftMotor);
	public VictorSP rightMotor=new VictorSP(RobotMap.rightMotor);
	public RobotDrive roboDrive = new RobotDrive(leftMotor, rightMotor);
	
	public double driveOutput = 0;
	
	public Encoder rightEnc = new Encoder(RobotMap.driveEncA,RobotMap.driveEncB);
	public Encoder leftEnc = new Encoder(RobotMap.driveEnc2A,RobotMap.driveEnc2B);
	
	public AHRS gyro;
	
	public double gAngle = 0;
	
	public double heading = 0; 
	public double pidOutput = 0;
	
	private static PIDController pidControl;
	
	private double maxRange = .6;
	
	public double goalAngle;
	
	public static double kP; 
	public static double kI;
	public static double kD;
	
	private double minSpinSpeed = 0;
	
    // Initialize your subsystem here
    public Chassis() {
        // Use these to get going:
        // setSetpoint() -  Sets where the PID controller should move the system
        //                  to
        // enable() - Enables the PID controller.
    	super("Chasssis", kP, kI,kD);
    	//table = NetworkTable.getTable("GRIP/highGoalData");
    	roboDrive.setSafetyEnabled(false);
    	gyro = new AHRS(SPI.Port.kMXP);
    	
        setOutputRange(-maxRange,maxRange);
		setPercentTolerance(.1);
		
		pidControl=getPIDController();
    }
    
    public void initDefaultCommand() {
        // Set the default command for a subsystem here.
        //setDefaultCommand(new MySpecialCommand());
    	setDefaultCommand(new AutoRoom());
    }
    
    protected double returnPIDInput() {
        // Return your input value for the PID loop
        // e.g. a sensor, like a potentiometer:
        // yourPot.getAverageVoltage() / kYourMaxVoltage; 
    	//Math.abs(leftEnc.get())-Math.abs(rightEnc.get());
    	return gyro.getAngle();
    }
    
    protected void usePIDOutput(double output) {
        // Use output to drive your system, like a motor
        // e.g. yourMotor.set(output);
    	//roboDrive.arcadeDrive(driveOutput, -output);
    	pidOutput = -output;
    	roboDrive.arcadeDrive(driveOutput,pidOutput);
    }

    public void resetEncoders(){
    	leftEnc.reset();
    	rightEnc.reset();
    }
    
    public void spinInPlace (double angle, double maxSpeed){
    	/* objective: spin in place for a given degree
    	 *  negative angle = counter clockwise, positive angle = clockwise
    	 *  input: angle = degree to spin, speed = maximum spin speed
    	
    	double setpoint = angle + gyro.getAngle();//Calculate setpoint
    	if(Math.abs(angle - 4) > 0){
    		coarseSpin(setpoint,maxSpeed);
    	}
    	drive(0,0);
    	Timer.delay(.5);
    	if (Math.abs(angle - .5) > 0) { // get to .5 degree
    		mediumSpin(setpoint,maxSpeed);
    	}
    	//drive(0,0);
    	//Timer.delay(.5);
    	//fineSpin(setpoint,maxSpeed); // the last .5 degree
    }
    
    private void coarseSpin(double setpoint, double maxSpeed){
    	double angleError; // hold the different between current angle and setpoint
    	double maxErrorAllowed = 4; // max error degree allowed
    	
    	setOutputRange(-maxSpeed,maxSpeed);
		setPercentTolerance(.01);
    	setSetpoint(setpoint);//set loop's setpoint
    	setPID(.017,0.01,0);//set PID Cemete: setPID(.02,0,0);
    	pidControl.reset();
    	enable();//Enable pid
    	angleError = maxErrorAllowed + 1; // set a value to enter while loop
    	while(angleError > maxErrorAllowed){
    		//System.out.println("angleError"+angleError+"Pid output: "+pidOutput+"Setpoint: "+setpoint+"Current Angle: "+gyro.getAngle());
    		//System.out.println("Coarse out"+pidOutput);
    		//roboDrive.arcadeDrive(0, pidOutput);
    		angleError = Math.abs(gyro.getAngle() - setpoint); // calculate angle error
    	}
    	disable();
    	System.out.println("Coarse Setpoint: "+setpoint+" Final Angle: "+gyro.getAngle());
    }
    
    private void mediumSpin(double setpoint,double maxSpeed){
    	double angleError; // hold the different between current angle and setpoint
    	double maxErrorAllowed = 1; // max error degree allowed
    	
    	setOutputRange(-.5,.5);
		setPercentTolerance(.01);
    	setSetpoint(setpoint);//set loop's setpoint
    	setPID(.22,0.1,0);//set PID 15000
    	pidControl.reset();
    	enable();//Enable pid
    	angleError = maxErrorAllowed + 1; // set a value to enter while loop
    	while(angleError > maxErrorAllowed){
    		//System.out.println("angleError"+angleError+"Pid output: "+pidOutput+"Setpoint: "+setpoint+"Current Angle: "+gyro.getAngle());
    		//System.out.println("Med out"+pidOutput);
    		//roboDrive.arcadeDrive(0, pidOutput);
    		angleError = Math.abs(gyro.getAngle() - setpoint); // calculate angle error
    	}
    	disable();
    	System.out.println("Med Setpoint: "+setpoint+" Final Angle: "+gyro.getAngle());
    }
    
    private void fineSpin (double setpoint,double maxSpeed){
    	double angleError; // hold the different between current angle and setpoint
    	double maxErrorAllowed = .2; // max error degree allowed
    	
    	setOutputRange(-.6,.6);
		setPercentTolerance(.01);
    	setSetpoint(setpoint);//set loop's setpoint
    	setPID(.4,.09,0);//set PID setPID(.75,.04,.05);
    	pidControl.reset();
    	enable();//Enable pid
    	angleError = maxErrorAllowed + 1; // set a value to enter while loop
    	while(angleError > maxErrorAllowed){
    		//System.out.println("angleError"+angleError+"Pid output: "+pidOutput+"Setpoint: "+setpoint+"Current Angle: "+gyro.getAngle());
    		//System.out.println("Fine out"+pidOutput);
    		//roboDrive.arcadeDrive(0, pidOutput);
    		angleError = Math.abs(gyro.getAngle() - setpoint); // calculate angle error
    	}
    	disable();
    	System.out.println("Fine Setpoint: "+setpoint+" Final Angle: "+gyro.getAngle());
    }
    
    public void pidSpin(double angle, double speed){
    	double setpoint = angle + gyro.getAngle();//Calculate setpoint
    	int speedDirection;
    	double minSpeed= .3;
    	if(angle > 0){
    		speedDirection = -1;
		}
    	else{
    		speedDirection = 1;
    	}
    	minSpeed *= speedDirection;
    	setOutputRange(-speed,speed);//Set the max speed
    	setSetpoint(setpoint);//set loop's setpoint
    	setPID(0.015,0,0);//set PID
    	//setPID(0.01,0.00015,0);//set PID
    	enable();//Enable pid
    	while(Math.abs((int)gyro.getAngle()-(int)setpoint)>3){
    		System.out.println("Pid output: "+pidOutput+"Setpoint: "+setpoint+"Current Angle: "+gyro.getAngle());
    		//drive(-pidOutput,pidOutput);//Spin
    		//roboDrive.arcadeDrive(0, pidOutput);
    	}
    	disable();
    	while((int)gyro.getAngle()!=(int)setpoint){
    		if(((gyro.getAngle() > setpoint && speedDirection > 0) || (gyro.getAngle() < setpoint && speedDirection < 0))){
    			//System.out.println("Current Angle: "+currentAngle+" Target Angle: "+targetAngle+"Speed Dir: "+speedDirection);
        		speedDirection = -speedDirection;
        		minSpeed *= speedDirection;
        	}
    		//roboDrive.arcadeDrive(0,minSpeed);
    	}
    	System.out.println("Setpoint: "+setpoint+" Final Angle: "+gyro.getAngle());
    	drive(0,0);//Stop spinning
    }
    
    public void drive(double leftValue,double rightValue){
    	roboDrive.tankDrive(leftValue, rightValue,true); 
    }
    
    public void tapDrive(double val){
    	resetEncoders();
    	double currentSpeed = .15;
    	double accelFactor = .00001;
    	int numTicks = 2;
    	if(val < 0){//Move the left side
    		while(leftEnc.get()!=numTicks){
    			currentSpeed += accelFactor;
    			drive(currentSpeed,0);
    		}
    		System.out.println("TAP LEFT ENC: "+leftEnc.get());
    	}
    	else{//Move the right side
    		while(rightEnc.get()!=numTicks){
    			currentSpeed += accelFactor;
    			drive(0,currentSpeed);
    		}
    		System.out.println("TAP RIGHT ENC: "+rightEnc.get());
    	}
    	drive(0,0);
    	System.out.println("TAP END");
    	
    }
    
    public void spin(double angle, double maxSpeed){
    	//Degree to spin. Positive value = clockwise, Negative Value = counter-clockwise.
    	//Speed is postive value between 0 - 1
    	int initAngle = (int)gyro.getAngle();
    	int targetAngle = (int)(angle+initAngle);
    	int eightyPercent = ((int)(angle*.8))+initAngle;
    	int currentAngle = 0;
    	int speedDirection;
    	int tries = 0;
    	double minSpeed = .35;
    	boolean stop = false;
    	
    	double speed = maxSpeed;
		if(angle < 0){
			speedDirection = -1;
		}
		else{			
			speedDirection = 1;
		}
		//currentAngle = (int)gyro.getAngle();
		//trySpin(eightyPercent,speed,speedDirection);//Init try to 80% of target angle
		currentAngle = (int)gyro.getAngle();
		System.out.println("80%: "+eightyPercent);
		//SmartDashboard.putNumber("Speed Direction",speedDirection);
		//SmartDashboard.putNumber("Speed", speed);
		//SmartDashboard.putNumber("Target Angle", targetAngle);
		//SmartDashboard.putNumber("Current Angle", currentAngle);
		//SmartDashboard.putNumber("Spin tries",tries);
		//SmartDashboard.putBoolean("Spin stop", stop);
		while(!isThereYet(currentAngle,targetAngle,speedDirection) && tries < 5){
			if(tries == 0){
				trySpin(eightyPercent,speed,speedDirection);
				tries++;
			}
			else{
				trySpin(targetAngle,speed,speedDirection);
			}
			//trySpin(targetAngle,speed,speedDirection);
			
			drive(0,0);
			Timer.delay(.5);
			currentAngle = (int)gyro.getAngle();
			
    		if(((currentAngle > targetAngle && speedDirection > 0) || (currentAngle < targetAngle && speedDirection < 0))){
    			System.out.println("Current Angle: "+currentAngle+" Target Angle: "+targetAngle+"Speed Dir: "+speedDirection);
        		speedDirection = -speedDirection;
        		speed *= .8;
        	}
    		if(speed < minSpinSpeed){
    			speed = minSpinSpeed;
    		}
    		tries++;
    		//SmartDashboard.putNumber("Speed Direction",speedDirection);
    		//SmartDashboard.putNumber("Speed", speed);
    		//SmartDashboard.putNumber("Target Angle", targetAngle);
    		//SmartDashboard.putNumber("Current Angle", currentAngle);
    		//SmartDashboard.putNumber("Spin tries",tries);
		}
		stop = true;
		System.out.println("Angle: "+currentAngle+"Target Angle: "+targetAngle);
		//SmartDashboard.putBoolean("Spin stop", stop);
    }
    
    private void trySpin(int targetAngle, double maxSpeed, int speedDirection){
    	resetEncoders();
    	double currentSpeed = .15;
    	double accelFactor = .00001;
		double rightSpeed;
    	double leftSpeed;
    	double prevEnc = 0;
    	boolean moved = false;
    	int currentAngle = 0;
    	leftSpeed = 0;
    	rightSpeed = 0;
    	
    	currentAngle = (int)gyro.getAngle();//Set init angle
    	prevEnc = leftEnc.get();//Get init enc count
    	while(!isThereYet(currentAngle,targetAngle,speedDirection)){
    		currentAngle = (int)gyro.getAngle();
    		if(!moved){
    			if(prevEnc != leftEnc.get()){
    				System.out.println("Speed at which robot moved: "+currentSpeed);
    				if(currentSpeed*1.2 > minSpinSpeed){
    					minSpinSpeed = currentSpeed*1.2;
    				}
    				moved = true;
    			}
    		}
    		if(currentSpeed < maxSpeed){
    			currentSpeed = currentSpeed + accelFactor;
    		}
    		else{
    			currentSpeed = maxSpeed;
    		}
    		leftSpeed = currentSpeed * speedDirection;
    		rightSpeed = -leftSpeed;
    		//SmartDashboard.putNumber("Spin Speed", currentSpeed);
    		drive(leftSpeed,rightSpeed);
    	}
    	drive(0,0);
    	/*
    	System.out.println("INIT ANGLE: "+initAngle);
    	System.out.println("CURRENT ANGLE: "+gyro.getAngle());
    	System.out.println("TARGET ANGLE: "+targetAngle);
    	*/
    }
    
    private boolean isThereYet(int currentAngle, int targetAngle, int speedDirection){
    	if((currentAngle >= targetAngle && speedDirection > 0) || (currentAngle <= targetAngle && speedDirection < 0)){
    		return true;
    	}
    	return false;
    }
    
    private double calcSpinCompensate(double leftEncCount, double rightEncCount,double speedDir){
    	double maxSpeed = .2;
    	double compensate = 0;//This value is added to the right side to adjust its speed to keep up with the left side
    	if(leftEncCount > 200){ //Delay compensate value to avoid diving by zero and giving a system a chance to move
    		compensate = (((leftEncCount/rightEncCount))-1.0); //Calculate percent difference of left and right
    		compensate *= 1.0;//encoder and multiplying it by an adjustment factor.    		
    	} 
    	
    	compensate *= -speedDir;
    	
    	//Cap compensate value at .2 to prevent beef jerky motion.
    	if(Math.abs(compensate) > maxSpeed){
    		compensate = maxSpeed * -speedDir;
    	}
    	return compensate;
    }
    //Return gyro angle
    public double gyroAngle(){ 
    	return gyro.getAngle();
    }
    
    //Reset gyro
    public void resetGyro(){
    	gyro.reset();
    }
    
    //Set heading
    public double setHeading(){
       heading = gyro.getAngle(); 
       return heading; 
    }
    
    //Return heading
    public double getHeading(){
    	return heading;
    }
    //Return output of pid loop
    public double getPidOutput(){
    	return pidOutput;
    }
    public double getDistance(Encoder enc){
    	double circumference = (6)*(Math.PI);
    	double inchPerPulse = (circumference/500); //* .99375;
    	return Math.abs(enc.get())*inchPerPulse;//((getEncCount()/360)*circumference);//
    }
    
    //Sets PID. This allow commands to use different PIDs.
    public void setPID(double p, double i, double d){
    	pidControl.setPID(p, i, d);
    }
    //Returns PID values
    public double getPVal(){
    	return pidControl.getP();
    }
    public double getIVal(){
    	return pidControl.getI();
    }
    public double getDVal(){
    	return pidControl.getD();
    }
    
    //Sequence for auto move. Provide the setpoint and PIDs
    public void initAutoMove(int setpoint, double p, double i, double d,String type){
    	setHeading();
    	setSetpoint(setpoint); //Give setpoint to PID loop
    	pidControl.setPID(p, i, d); //Set the PIDs to given values
    	enable(); //Enable PIDs loop. Make sure to disable it when command is done.
    }
    public void setDriveOutput(double weed) {
    	driveOutput = weed;
    }
    public void changeRange(double pot) {
    	maxRange = pot;
    	pidControl.setOutputRange(-maxRange, maxRange);
    }
    
    public double setGoalAngle(double angle){
    	goalAngle = angle;
    	return goalAngle;
    }
    public double getSetgoalAngle(){
    	return goalAngle; 
    }
   
}
