package org.usfirst.frc.team6002.robot.commands;

import org.usfirst.frc.team6002.robot.Robot;

import edu.wpi.first.wpilibj.command.CommandGroup;

/**
 *
 */
public class AutoGateHighGoal extends CommandGroup {
    
    public  AutoGateHighGoal() {
        // Add Commands here:
        // e.g. addSequential(new Command1());
        //      addSequential(new Command2());
        // these will run in order.

        // To run multiple commands at the same time,
        // use addParallel()
        // e.g. addParallel(new Command1());
        //      addSequential(new Command2());
        // Command1 and Command2 will run in parallel.

        // A command group will require all of the subsystems that each member
        // would require.
        // e.g. if Command1 requires chassis, and Command2 requires arm,
        // a CommandGroup containing them would require both the chassis and the
        // arm.
    	addSequential(new GoToAngle(Robot.pivot.fourtyFive));
    	addSequential(new FullSpeedForward(60,.5,true));//61
    	addSequential(new GoToAngle(Robot.pivot.home));
    	addSequential(new DriveStraightWithGyro(60,.6,0.02,true));
    	
    	addSequential(new Turn(45,.65));//50
    	//addSequential(new DriveStraightWithGyro(50,0.7,0.02,true));
    	addSequential(new DriveStraightWithGyro(111,.6,0.02,true));
    	addSequential(new Turn(90,.65));
    	//addSequential(new FullSpeedForward(40,.6,true));
    	//addSequential(new FullSpeedForward(50,.8,true));
    	//addSequential(new ReverseIntake());
    }
}
