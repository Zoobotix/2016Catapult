
package org.usfirst.frc.team6002.robot;

import edu.wpi.first.wpilibj.IterativeRobot;
import edu.wpi.first.wpilibj.Joystick;
import edu.wpi.first.wpilibj.RobotDrive;
import edu.wpi.first.wpilibj.Timer;
import edu.wpi.first.wpilibj.VictorSP;


//import edu.wpi.first.wpilibj.command.Command;
//import edu.wpi.first.wpilibj.command.Scheduler;
//import edu.wpi.first.wpilibj.livewindow.LiveWindow;
//import edu.wpi.first.wpilibj.smartdashboard.SendableChooser;
//import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;

public class Robot extends IterativeRobot {

	RobotDrive Leftdrive;
	RobotDrive Rightdrive;
	Joystick mXboxController; 
	Joystick controlStick;
	VictorSP frontLeft,frontRight, rearLeft, rearRight;

	public void robotInit() {	// this code will be ran each time we power on the robot
	
		//Controllers
		mXboxController = new Joystick(1); // depends on the usb connected to computer
		controlStick = new Joystick(0);
		
		//Left Side
		frontLeft = new VictorSP(0);
		frontRight = new VictorSP(1);
		
		//Right Side
		rearLeft = new VictorSP(1);
		rearRight = new VictorSP(1);
		
		//Grouping Motors
		Leftdrive = new RobotDrive(frontLeft, rearLeft);
		Rightdrive = new RobotDrive(frontRight, rearRight);
	}


public void autonomousInit() { // triggers when we enter autonomous


}


	public void autonomousPeriodic() { // this code runs periodically in autonomous
		while (isAutonomous() && isEnabled()) {
			Leftdrive.drive(0.5, 0.0);
			Rightdrive.drive(0.5, 0.0);
			Timer.delay(0.5);
			Leftdrive.drive(0.0, 0.0);
			Rightdrive.drive(0.0, 0.0);

}
}




public void teleopInit(){ // This triggers every time we enter telop mode. 

	mXboxController = new Joystick(0); // the number within the parathesis depends on the controllers usb order always check
	controlStick = new Joystick(1);

}




	public void teleopPeriodic() {
		while (isOperatorControl() && isEnabled()) {
			Leftdrive.setSafetyEnabled(true);
			Rightdrive.setSafetyEnabled(true);
			Leftdrive.tankDrive(mXboxController.getRawAxis(1), mXboxController.getRawAxis(1));
			Rightdrive.tankDrive(mXboxController.getRawAxis(5) , mXboxController.getRawAxis(5));
			Timer.delay(0.01); 
			}

			if(mXboxController.getRawAxis(1) > 0.1){
				frontLeft.set(1.0);
				frontRight.set(1.0);
				rearLeft.set(1.0);
				rearRight.set(1.0);
			}else if(mXboxController.getRawAxis(1) > -0.1){
				frontLeft.set(1.0);
				frontRight.set(1.0);
				rearLeft.set(1.0);
				rearRight.set(1.0);
			}
		} // this will constantly update motors and speed controllers periodically

	public void teleopOperator(){
		
		
	}

}