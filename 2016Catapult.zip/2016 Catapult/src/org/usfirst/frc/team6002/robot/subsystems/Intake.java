package org.usfirst.frc.team6002.robot.subsystems;

import org.usfirst.frc.team6002.robot.RobotMap;
import org.usfirst.frc.team6002.robot.commands.IntakeRest;

import edu.wpi.first.wpilibj.Encoder;
import edu.wpi.first.wpilibj.VictorSP;
import edu.wpi.first.wpilibj.command.PIDSubsystem;

/**
 *
 */
public class Intake extends PIDSubsystem {
	
	private static double kP = 0.02; 
	private static double kI = 0; 
	private static double kD = 0;

	VictorSP ballsuck = new VictorSP(RobotMap.ballsuck);
	
	
    // Initialize your subsystem here
    public Intake() {
        // Use these to get going:
        // setSetpoint() -  Sets where the PID controller should move the system
        //                  to
        // enable() - Enables the PID controller.
    	super("Intake",kP, kI, kD); 
    	disable();    	
    }
    
    public void initDefaultCommand() {
        // Set the default command for a subsystem here.
        setDefaultCommand(new IntakeRest());
    }
    
    protected double returnPIDInput() {
        // Return your input value for the PID loop
        // e.g. a sensor, like a potentiometer:
        // yourPot.getAverageVoltage() / kYourMaxVoltage;
    	return 0.0; 
    }
    
    protected void usePIDOutput(double output) {
        // Use output to drive your system, like a motor
        // e.g. yourMotor.set(output);
    	//intakeMotor.set(output); 
    }
    
    public void intakeBall(){
    	ballsuck.set(1);
    }
    public void reverseBall(){
    	ballsuck.set(-1);
    }
    public void intakeRest(){
    	ballsuck.set(0);
    }
}
